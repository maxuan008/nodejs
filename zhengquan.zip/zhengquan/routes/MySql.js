//console.log("11");
var config = require('./config');


var mysql = require('mysql');

//console.log('ccccc');
var connection = mysql.createConnection({
	  host     : 'localhost',
	  user     : config.user,
	  password : config.password,
	  database : 'zhengquan'
});

connection.connect();

module.exports = connection;

/*
 var mysql      = require('mysql');
 var connection = mysql.createConnection({
   host     : 'localhost',
   user     : 'root',
   password : '123456',
   database : 'zhengquan'
 });

 connection.connect();

 connection.query('SELECT * FROM `gupiao`  where 1', function(err, results, fields) {
   if (err) throw err;
   console.log(results);
   console.log(fields);
   //console.log('The solution is: ', rows[0].solution);
 });

 //connection.end();
	    
*/
