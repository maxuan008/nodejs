//console.log('config');
module.exports = {
		cookiesecret: 'manyproj',
		db: 'mx',
		host:'127.0.0.1',
		port: 27017,
		hostprot:3009,
		
		httpPort:1228,
		

		mysqldb: 'zhengquan',
		user     : 'root',
		password : '123456',
		dbport:3306
		};


